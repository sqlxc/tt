Changelog
=========

## 2019/09/01 (v0.1.4)
 - [bugfix] Better support for python3 #22

## 2019/05/21 (v0.1.3)
 - [bugfix] Some bug fixes
 - [feat] Support py3


## 2017/03/23 (v0.1.0)
 - Initial release. v0.1.0
