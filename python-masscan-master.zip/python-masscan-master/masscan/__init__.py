# -*- coding: utf-8 -*-
"""Init file for the masscan bindings."""
from .masscan import *

__author__ = 'MyKings (xsseroot@gmail.com)'
__version__ = '0.1.4'
__last_modification__ = '2019.09.02'

